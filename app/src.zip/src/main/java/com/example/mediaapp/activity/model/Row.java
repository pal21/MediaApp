package com.example.mediaapp.activity.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/*
 model clas for getting data for rows
 */
public class Row {

    @SerializedName("title")
    @Expose
    private String title;
    @SerializedName("description")
    @Expose
    private String description;
    @SerializedName("imageHref")
    @Expose
    private String imageHref;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public String getImageHref() {
        return imageHref;
    }

}